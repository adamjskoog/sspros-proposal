# System Solutions Pros office toolkit

Prepared for owner adaptation · November 1, 2026

These blank templates support the website proposal. They make no assessment of current internal practices. Keep a blank master, select the templates that help, and use working copies only in the business’s own controlled storage. Nothing is connected to private systems.

## 1. Approved public facts sheet

- Business name and preferred short name: [ ]
- One-sentence business definition: [ ]
- Primary customer groups and preferred services: [ ]
- Services offered and limits: [ ]
- Areas served by service type: [ ]
- Public phone, email, website, and profile links: [ ]
- Ordinary office hours: [ ]
- Emergency number, availability, and geographic scope: [ ]
- Approved response wording: [ ]
- Company operating history: [ ]
- Team experience, with the basis clearly explained: [ ]
- Project count, scope, source, and date: [ ]
- Credential descriptions and verification dates: [ ]
- Approved partner/dealer/affiliation wording: [ ]
- Review source, count, and checked date: [ ]
- Approval owner and next review date: [ ]

Use the included claims CSV to resolve existing public questions. Supporting documents can remain private with the owners; the outside reviewer needs only approved public wording.

## 2. Inquiry tracker field guide

Use `sspro-blank-inquiry-tracker.csv`. It is deliberately empty.

| Field | Use |
|---|---|
| Inquiry_ID | A unique reference used in related estimate and project records. |
| Received_Date | Date and time received; use one consistent timezone. |
| Source | Website form, phone, email, referral, or other known source. |
| Service | Requested work using the agreed service list. |
| City_or_ZIP | Location needed to assess service coverage. |
| Urgency | Customer-stated need; follow the business’s own urgent-call process. |
| Contact_Name | Name needed to respond. |
| Preferred_Contact_Method | Email or phone, as selected by the customer. |
| Contact_Details | Details for the selected method. |
| Status | One of the agreed statuses below. |
| Assigned_To | The person accountable for the next step. |
| Next_Action | A specific action such as request site details. |
| Next_Action_Due | The internally chosen follow-up date. |
| Estimate_Sent_Date | Date the current estimate was issued, if applicable. |
| Outcome | Won, lost, unsuitable, no response, or still open. |
| Outcome_Reason | Known reason; do not guess. |
| Notes | Short relevant notes; avoid unnecessary personal detail. |

Suggested statuses: New; Reviewing fit; Awaiting details; Preparing estimate; Estimate sent; Accepted; Scheduled; Closed. Use separate outcome fields so “Closed” does not imply won or lost.

Daily review: assign new items; check due follow-ups; update status after contact; ensure every open item has a next action.

Weekly review: review overdue/unassigned items; resolve missing information; close stale items with an agreed reason; note common questions for the website.

## 3. Estimate preparation and follow-up

- Inquiry/reference: [ ]
- Requested work and project location: [ ]
- Site contact and preferred reply method: [ ]
- Requested timing and known constraints: [ ]
- Existing conditions described or assessed: [ ]
- Plans, photographs, measurements, or site visit needed: [ ]
- Proposed inclusions: [ ]
- Assumptions and exclusions to confirm: [ ]
- Access, coordination, and permit questions for the estimator: [ ]
- Open questions and who will answer them: [ ]
- Estimator and target next action: [ ]
- Estimate reference/version/date: [ ]
- Approved to send by: [ ]
- Sent date and agreed follow-up date: [ ]
- Decision and reason, where known: [ ]

This is a preparation checklist, not a pricing schedule or contract. Use the owners’ established estimating and approval process. The follow-up CSV tracks the latest estimate version and next contact.

## 4. Project handoff and document checklist

- Project reference and service: [ ]
- Latest agreed scope/estimate version: [ ]
- Written approval recorded by/date: [ ]
- Responsible project person: [ ]
- Site contact, access, and agreed schedule: [ ]
- Materials, coordination, and prerequisites to confirm: [ ]
- Open scope questions: [ ]
- Approved changes and dates: [ ]
- Completion documentation required: [ ]
- Outstanding approvals or documents, owner, and due date: [ ]
- Invoice-status question, if any, routed to: [ ]
- Customer follow-up owner: [ ]
- Completion/closeout recorded by/date: [ ]

Folder example, if useful in existing storage:

```
[Project reference] - [Short project name]
  01 Request and site information
  02 Estimate and approvals
  03 Agreed scope and schedule
  04 Changes and correspondence
  05 Completion documents
  06 Approved publication material
```

Use dated, versioned filenames. Store only approved publication material in the final folder. Owners retain their existing accounting and document-retention rules.

## 5. Case-study and publication worksheet

- Internal project reference: [ ]
- Proposed public title: [ ]
- Service family and public location description: [ ]
- What did the customer need? [ ]
- What constraints mattered? [ ]
- What did SSPros actually do? [ ]
- What result can be documented? [ ]
- Evidence for any measured result: [ ]
- Approved images and accurate captions: [ ]
- Alternative text describing important visual information: [ ]
- Customer/site naming allowed? [ ]
- Photo use permitted on which channels? [ ]
- Testimonial excerpt and attribution approved? [ ]
- Permission recorded by, reference, and date: [ ]
- Content approval owner/date: [ ]
- Published location and review date: [ ]

Record photo and testimonial permissions separately. Do not infer permission to publish from completion of a project. Do not publish private addresses, identifiable people, security details, or customer documents without appropriate permission and review.

## 6. Five message drafts

### Inquiry acknowledgement

Hi [Name], thanks for contacting System Solutions Pros about [service] in [city]. We’ve received your details and will review the project information.

[Responsible person] will follow up by [confirmed date/time] about the next step. An appointment is confirmed once we agree on the details with you.

### Missing information

Hi [Name], to assess your project, could you send [specific missing information]? Please also confirm the project city or ZIP and the best way to reach you.

Once we have that information, we can advise on [site review / estimate preparation / the appropriate next step].

### Estimate follow-up

Hi [Name], I’m following up on estimate [reference/version] for [brief scope], sent on [date]. Do you have any questions about the scope or next steps?

If your plans or timing have changed, let us know so we can keep our records current.

### Agreed appointment confirmation

Hi [Name], this confirms the [site visit / agreed work] for [date and arrival window] at [location]. The site contact is [name and number].

Please confirm [access arrangements or preparation]. If anything changes, contact [business contact]. The agreed purpose of this visit is [purpose].

### Honest review request

Hi [Name], thank you for choosing System Solutions Pros for [project]. If you would like to share your experience, you can leave an honest review here: [approved review link].

If you have a question about the completed work, please contact [business contact].

Apply review requests consistently to eligible customers. No incentives or selection based only on expected positive feedback. Reference: https://support.google.com/business/answer/7400114?hl=en

## 7. Monthly review agenda

- Period reviewed: [ ]
- Public facts or links requiring correction: [ ]
- Services and coverage still accurate? [ ]
- Inquiry delivery checked by the authorized provider? [ ]
- Open/overdue follow-ups, if the owners use the tracker: [ ]
- Inquiry fit by service, if records are available: [ ]
- Estimate outcomes, including pending items: [ ]
- Common questions to answer on the website: [ ]
- New approved project proof: [ ]
- Chosen next improvement: [ ]
- Responsible person and due date: [ ]

Use the monthly CSV definitions consistently. A phone-link click is contact intent, not a confirmed conversation. A form acceptance is not proof of inbox delivery or a sale. Leave unknown values blank and explain why.

## 8. Public update checklist

1. Identify the page/profile and current issue.
2. Check the approved facts sheet and source.
3. Draft replacement wording and obtain the appropriate approval.
4. Have the authorized account owner/provider publish the update.
5. Recheck the public page, its links, and mobile presentation.
6. Record the publication date, reviewer, and next review date.

## 9. Choosing what to adopt first

Start with the public facts register and one small inquiry record. Add estimate, handoff, and evidence worksheets only where they reduce repeated work. If an existing system already holds the same information clearly, adapt its fields instead of maintaining a second competing record.
